package lisp;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Lisp {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner s = new Scanner(new File("C:\\Users\\user\\IdeaProjects\\CS201\\src\\lisp\\lisps.txt"));
        while (s.hasNextLine()) {
            String line = s.nextLine();
            String lines[] = line.split(" ");


            Stack major = new Stack<String>();
            Stack temp = new Stack<String>();
            for (int i = 0; i < lines.length; i++) {
                while (!lines[i].equals(")")) {
                    major.push(lines[i]);
                    i++;
                }
                while (!major.peek().equals("(")) {
                    temp.push(major.pop());
                }
                major.pop();
                String mode = (String) temp.pop();
                float value;
                //opertations:
                {
                  //  System.out.println(mode);
                    if (mode.equals("+")) {
                        value = 0;
                        while (!temp.isEmpty()) {
                            value += Float.parseFloat((String) temp.pop());
                        }
                    } else if (mode.equals("-")) {
                        value = Float.parseFloat((String)temp.pop());
                        while (!temp.isEmpty()) {
                            value -= Float.parseFloat((String) temp.pop());
                        }
                    } else if (mode.equals("*")) {
                        value = 1;
                        while (!temp.isEmpty()) {
                            value *= Float.parseFloat((String) temp.pop());
                        }
                    } else if(mode.equals("/")) {
                        value = Float.parseFloat((String) temp.pop()) / Float.parseFloat((String) temp.pop());
                        while (!temp.isEmpty()) {
                            value /= Float.parseFloat((String) temp.pop());
                        }
                    }
                    else {
                       // System.out.println("Unknown mode error. mode = " + mode);
                        value = Float.parseFloat(null);
                    }
                }
                major.push("" + value);


            }
            System.out.println(line + " Returns " + major.pop());


        }
    }
}
